# The Broken Bridge v0.5.0 teacher review

The build covers one clearing and its two existing solutions. The review ZIP contains `downloads/Broken-Bridge-v0.5.0.html`. Extract the ZIP and double-click that file. If your browser blocks local files, run `python3 -m http.server 8000 --bind 127.0.0.1` in the downloads folder and use `http://127.0.0.1:8000/Broken-Bridge-v0.5.0.html`.

## Changes and asset provenance

- The 1774 × 887 clearing comes from a ChatGPT ImageGen edit of the original illustrated plate. The edit was directed to keep the camera, shelter, banks and stepping stones registered and to resolve bark, shelter wood, pebbles, and plant detail. It replaces the 1470 × 735 plate derivatives. The foreground, characters, physical objects, bridge states, and audio reuse their existing authored assets. The original edited PNG and the script that prepares the WebP layers are shipped with the source. Original edit SHA-256 `690207f33ad6673cc9eee0f1aeeb2409312b6c136bec6ecadc2e4110ec94f9f6`.
- Water glints advect through individual stretches of river. Foreground leaves and canopy sway, and lit motes drift near the shelter. With reduced motion, these layers hold a static composition. Illustrated mist remains part of the plate.
- Lin and the scout render at 88 and 81 nominal world units, up from 73 and 66. Their contact shadows and carry heights were adjusted. Desktop bridge work frames more closely, and distant landmark marks give way to nearby prompts and focus labels.
- Both shore paths were traced in foot-space. The broken bridge remains closed until secured, and the marked ford follows the stone path. Keyboard, taps, guided walks and crossings use the same regions. The repair still has two board fits and a hook-and-tension rope step. The ranger now follows the authored ford approach and stones on delivery.

## Navigation regression

The browser replay started at the same far landing on each build and held Up for 1.15 seconds. On the bridge, v0.4 moved from `(450, 288)` to `(450, 202)` in the painted trees. V0.5 stopped at `(450, 267.76)` on the lookout trail. At the ford, v0.5 stopped at `(829, 283.82)` from `(829, 299)`. Three taps on the portrait background produced zero displacement from either landing. Separate unit checks cover gaps between crossings, unavailable routes and safe recovery of legacy coordinates.

## Verification

| Gate | Result |
|---|---|
| Source and scope | **PASS.** Restored both approved v6 references and ran the repository v8 verification. Approved releases and audio are unchanged. The v0.4 source baseline is `446235581430221f0d60865686a648d48efc75ed`. |
| Gameplay | **PASS in Chromium.** 14 unit tests and four complete network-denied journeys. Both language profiles, both routes, incorrect recommendations and placements, repair and ford work with direct and guide controls, settings, save/reload, teacher export, and reset. Live v0.2 and v0.3 partial saves resumed in v0.5. |
| Navigation | **PASS for tested inputs.** Both keyboard edge cases, portrait background taps, and both route traversals. See `navigation-evidence.json` and the three collision stills. |
| Offline | **PASS** for the ZIP byte match and complete network-denied journeys with the extracted HTML served to Chromium. **BLOCKED** for a literal double-click launch in the managed Chromium environment, which returns `ERR_BLOCKED_BY_ADMINISTRATOR` for `file:` navigation. |
| Visual and motion | **PASS for evidence capture and inspection.** Side-by-side captures show more defined foliage, roof and river texture, larger characters, and fewer visible markers. Actual gameplay motion clips show moving water, subtle canopy sway and ongoing walk/carry cycles. In one same-camera two-frame sample, a central river crop changed at 805 pixels above a 12-value channel threshold in v0.5 versus 201 in v0.4. Teacher visual acceptance remains open. |
| Voice | **PASS** for unchanged packaged audio and actual offline replay in browser tests. **NOT TESTED** for a new human pronunciation or classroom review. |
| Device and curriculum | **PASS** for Chromium touch emulation at 390×844 and 844×390. **NOT TESTED** on a physical iPhone or in native Safari, or for current textbook alignment and learner review. |

## Evidence

The ZIP includes desktop and both phone layouts, Lin’s dialogue, damage and repair, physical carry and placement, ford outcome, three Chromium gameplay clips, the v0.4/v0.5 comparison and the boundary checks. The PNG comparisons and captures come from actual running builds. Refer to the v0.4 QA and v0.3 benchmark evidence for the prior REGOLITH and Paper Town review. The location still uses an illustrated 2.5D composition, and the interaction controls and camera can be assessed directly in the playthrough.

Reproduce with `npm test`, `npm run build`, `python3 tests/browser.py`, `python3 tests/navigation_browser.py`, and `BRIDGE_TEST_CASE=motion python3 tests/browser.py`.

```text
5ecb11dd066102f7c96d51dc4dea5f62d38d26a376a5c63ef3a9c739ee4ac240  Broken-Bridge-v0.5.0.html
bc8f8e982daebb64c07c840c8db13856e61ffeb46715eeed789c1b860c97e788  Broken-Bridge-v0.5.0-Offline.zip
```
