# The Broken Bridge v0.6.0

**Teacher preview · Illustrative language practice**

## Open the game

Extract this ZIP. Double-click `play/Broken-Bridge-v0.6.0.html` from the extracted folder. If a browser policy blocks local files, follow the localhost steps in `play/OFFLINE-README.txt`. The game runs without an Internet connection. Click **Enable sound** for Ranger Lin, the forest mix and action cues.

## Review the work

- `qa/QA-REPORT.md` gives the exact commit, build hashes and results.
- `evidence/video/gameplay-with-audio.mp4` includes sound from the running game. `stationary-living.mp4` and `stationary-reduced.mp4` show the same camera position. `notice-consequence.mp4` shows the interview changing Lin’s action.
- `evidence/screenshots/` contains the desktop and phone layouts, survey, rigging, both outcomes and v0.5 comparison.
- `source/EAL-Game/games/broken-bridge-25d-prototype/` contains the editable project, original art, manifests, recorded voices, package lock and tests. Historical v0.1 to v0.4 screenshot and video folders stay on GitHub. The legacy HTMLs needed for save migration tests are included.
- `SOURCE-SHA.txt` identifies the source used here. `SHA256SUMS.txt` inventories the delivered files.

## Rebuild using the supplied npm dependencies

Use Node.js 24 and Python 3.12. From the root of the extracted Review ZIP on macOS/Linux, run:

```sh
npm cache add "$PWD"/dependencies/*.tgz --offline --cache "$PWD/.npm-offline"
review_root="$PWD"
cd source/EAL-Game/games/broken-bridge-25d-prototype
npm ci --offline --ignore-scripts --no-audit --no-fund --cache "$review_root/.npm-offline"
npm test
npm run build
cmp build/Broken-Bridge-v0.6.0.html "$review_root/play/Broken-Bridge-v0.6.0.html"
```

On Windows set the equivalent absolute cache and archive paths, or use `npm ci --ignore-scripts` when the npm registry is available. Exact environment details and browser test commands are in the report and the project's README.
