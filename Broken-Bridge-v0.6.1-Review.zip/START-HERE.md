# The Broken Bridge v0.6.1

**Teacher preview**

Extract this ZIP and double-click `play/Broken-Bridge-v0.6.1.html`. If a local browser policy blocks files, follow the localhost instructions in `play/OFFLINE-README.txt`.

The river now moves through the scenery’s own water texture. See `evidence/river-comparison.mp4` for matching river views from both builds. Screenshots show the full clearing and both phone orientations. A separate still records the reduced-motion view.

`qa/QA-REPORT.md` records the exact source, build hashes and checks. The editable project is under `source/EAL-Game/games/broken-bridge-25d-prototype/`. The matching npm tarballs are in `dependencies/`.

## Rebuild offline

Use Node.js 24 and Python 3.12. On macOS or Linux, run these commands from the extracted Review ZIP directory.

```sh
npm cache add "$PWD"/dependencies/*.tgz --offline --cache "$PWD/.npm-offline"
review_root="$PWD"
cd source/EAL-Game/games/broken-bridge-25d-prototype
npm ci --offline --ignore-scripts --no-audit --no-fund --cache "$review_root/.npm-offline"
npm test
npm run build
cmp build/Broken-Bridge-v0.6.1.html "$review_root/play/Broken-Bridge-v0.6.1.html"
```

On Windows use equivalent absolute cache and archive paths or run `npm ci --ignore-scripts` with the npm registry available. The source README includes Chromium and Playwright instructions for the browser checks.
