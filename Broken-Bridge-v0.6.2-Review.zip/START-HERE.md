# The Broken Bridge v0.6.2

**Teacher preview**

Extract this ZIP and double-click `play/Broken-Bridge-v0.6.2.html`. If a browser policy blocks local files, follow the localhost instructions in `play/OFFLINE-README.txt`.

Choose **Enable sound**, then open **Settings → Audio**. Adjust Master, Voice, Ambience, Sound effects, and Music. Turn on **Music** to hear the woodland score, and use **Preview Ranger Lin** to check the level of the dialogue.

The actual game-output recording is `evidence/audio-mixer-preview.mp4`. The settings views at desktop and phone sizes are beside it. `qa/QA-REPORT.md` records the exact source, build hashes, and checks.

The editable project is under `source/EAL-Game/games/broken-bridge-25d-prototype/`. Matching npm tarballs are in `dependencies/`.

## Rebuild offline

Use Node.js 24 and Python 3.12. From the directory containing this file on macOS or Linux, run:

```sh
npm cache add "$PWD"/dependencies/*.tgz --offline --cache "$PWD/.npm-offline"
review_root="$PWD"
cd source/EAL-Game/games/broken-bridge-25d-prototype
npm ci --offline --ignore-scripts --no-audit --no-fund --cache "$review_root/.npm-offline"
npm test
npm run build
cmp build/Broken-Bridge-v0.6.2.html "$review_root/play/Broken-Bridge-v0.6.2.html"
```

On Windows use equivalent absolute cache and archive paths or run `npm ci --ignore-scripts` with the npm registry available. The source README includes Chromium and Playwright instructions for the browser checks.
