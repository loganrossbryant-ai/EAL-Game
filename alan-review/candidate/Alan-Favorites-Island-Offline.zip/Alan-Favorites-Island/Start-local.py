from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
root=Path(__file__).resolve().parent/'play'
print('Alan and Pip: open http://127.0.0.1:8079/ ; Ctrl+C to stop.')
ThreadingHTTPServer(('127.0.0.1',8079),partial(SimpleHTTPRequestHandler,directory=str(root))).serve_forever()
