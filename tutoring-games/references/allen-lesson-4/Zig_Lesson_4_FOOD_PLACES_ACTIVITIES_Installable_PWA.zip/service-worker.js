/* Zig food/place/activity language edition; preserves other approved game caches. */
const CACHE_NAME='zig-allen-food-places-activities-20261117-v1';
const PREFIX='zig-allen-food-places-activities-';
const REQUIRED=['./','./index.html','./manifest.webmanifest','./icon-192.png','./icon-512.png'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE_NAME).then(cache=>cache.addAll(REQUIRED)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith(PREFIX)&&k!==CACHE_NAME).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET'||new URL(event.request.url).origin!==self.location.origin)return;
  event.respondWith((async()=>{let cache=await caches.open(CACHE_NAME);let hit=await cache.match(event.request);if(hit)return hit;try{let res=await fetch(event.request);if(res.ok)await cache.put(event.request,res.clone());return res}catch(e){if(event.request.mode==='navigate')return await cache.match('./index.html')||Response.error();return Response.error();}})());
});
